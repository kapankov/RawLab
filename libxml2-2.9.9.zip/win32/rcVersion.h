/*
  rcVersion.h
  This file is generated automatically by configure.js.
*/

#define LIBXML_MAJOR_VERSION 2
#define LIBXML_MINOR_VERSION 9
#define LIBXML_MICRO_VERSION 9
#define LIBXML_DOTTED_VERSION "2.9.9"
